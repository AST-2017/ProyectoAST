CREATE PROCEDURE `verReservasCliente`(IN `_dni` CHAR(9))
  BEGIN
  IF (SELECT EXISTS(SELECT * FROM clientes WHERE clientes.dni = _dni)) THEN
    SELECT
      reservas.precio,
      reservas.vueloDirectoSalida,
      reservas.vueloDirectoRegreso,
      reservas.fechaSalida,
      reservas.fechaRegreso,
      reservas.origen,
      reservas.destino,
      reservas.codigoIATAOrigen,
      reservas.codigoIATADestino,
      reservas.aerolineaSalida,
      reservas.aerolineaRegreso
    FROM clientes,reservas
    WHERE clientes.dni = _dni AND clientes.id = reservas.id_cliente;
  ELSE
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT ='No existe ningun cliente registrado con este DNI.';
  END IF;
END