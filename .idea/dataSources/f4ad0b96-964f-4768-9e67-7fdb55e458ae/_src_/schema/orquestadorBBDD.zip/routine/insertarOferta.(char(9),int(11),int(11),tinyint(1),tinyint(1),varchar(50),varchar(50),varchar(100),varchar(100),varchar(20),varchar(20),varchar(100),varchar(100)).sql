CREATE PROCEDURE `insertarOferta`(IN `_dni`                CHAR(9), IN `_id_oferta_vuelo` INT(11), IN `_precio` INT(11),
                                  IN `_vueloDirectoSalida` TINYINT(1), IN `_vueloDirectoRegreso` TINYINT(1),
                                  IN `_fechaSalida`        VARCHAR(50), IN `_fechaRegreso` VARCHAR(50),
                                  IN `_origen`             VARCHAR(100), IN `_destino` VARCHAR(100),
                                  IN `_codigoIATAOrigen`   VARCHAR(20), IN `_codigoIATADestino` VARCHAR(20),
                                  IN `_aerolineaSalida`    VARCHAR(100), IN `_aerolineaRegreso` VARCHAR(100))
  BEGIN
  DECLARE _id_cliente INTEGER DEFAULT 0;

  IF(SELECT EXISTS(SELECT * FROM clientes WHERE clientes.dni = _dni)) THEN
    SET _id_cliente = (SELECT clientes.id FROM clientes WHERE clientes.dni = _dni);
    DELETE FROM ofertas WHERE ofertas.id_cliente = _id_cliente;
    INSERT INTO ofertas(id_cliente,
                        id_oferta_vuelo,
                        precio,
                        vueloDirectoSalida,
                        vueloDirectoRegreso,
                        fechaSalida,
                        fechaRegreso,
                        origen,
                        destino,
                        codigoIATAOrigen,
                        codigoIATADestino,
                        aerolineaSalida,
                        aerolineaRegreso)
    VALUES(_id_cliente,
           _id_oferta_vuelo,
           _precio,
           _vueloDirectoSalida,
           _vueloDirectoRegreso,
           _fechaSalida,
           _fechaRegreso,
           _origen,
           _destino,
           _codigoIATAOrigen,
           _codigoIATADestino,
           _aerolineaSalida,
           _aerolineaRegreso);
  ELSE
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT ='No existe ningun cliente registrado con este DNI.';
  END IF;
END