CREATE PROCEDURE `obtenerEmail`(IN `_dni` CHAR(9))
  BEGIN
IF (SELECT EXISTS(SELECT * FROM clientes WHERE clientes.dni = _dni)) THEN
  SELECT email FROM clientes WHERE clientes.dni = _dni;
ELSE
  SIGNAL SQLSTATE '45000'
  SET MESSAGE_TEXT ='No existe ningun cliente registrado con este DNI.';
END IF;
END