CREATE PROCEDURE `insertarReserva`(IN `_dni` CHAR(9), IN `_id_oferta_vuelo` INT(11))
  BEGIN
  DECLARE _id_cliente INTEGER DEFAULT 0;
  DECLARE _precio INTEGER DEFAULT 0;
  DECLARE _vueloDirectoSalida BOOLEAN DEFAULT TRUE;
  DECLARE _vueloDirectoRegreso BOOLEAN DEFAULT TRUE;
  DECLARE _fechaSalida VARCHAR(50) DEFAULT NULL;
  DECLARE _fechaRegreso VARCHAR(50) DEFAULT NULL;
  DECLARE _origen VARCHAR(100) DEFAULT NULL;
  DECLARE _destino VARCHAR(100) DEFAULT NULL;
  DECLARE _codigoIATAOrigen VARCHAR(20) DEFAULT NULL;
  DECLARE _codigoIATADestino VARCHAR(20) DEFAULT NULL;
  DECLARE _aerolineaSalida VARCHAR(100) DEFAULT NULL;
  DECLARE _aerolineaRegreso VARCHAR(100) DEFAULT NULL;

  IF(SELECT EXISTS(SELECT * FROM clientes WHERE clientes.dni = _dni)) THEN
   IF (SELECT EXISTS(
       SELECT *
       FROM ofertas,clientes
       WHERE
         clientes.dni = _dni AND
         clientes.id = ofertas.id_cliente AND
         ofertas.id_oferta_vuelo = _id_oferta_vuelo)
   ) THEN

     SET _id_cliente = (SELECT clientes.id FROM clientes WHERE clientes.dni = _dni);
     SET _precio = (SELECT ofertas.precio FROM ofertas WHERE ofertas.id_cliente = _id_cliente AND ofertas.id_oferta_vuelo = _id_oferta_vuelo);
     SET _vueloDirectoSalida = (SELECT ofertas.vueloDirectoSalida FROM ofertas WHERE ofertas.id_cliente = _id_cliente AND ofertas.id_oferta_vuelo = _id_oferta_vuelo);
     SET _vueloDirectoRegreso = (SELECT ofertas.vueloDirectoRegreso FROM ofertas WHERE ofertas.id_cliente = _id_cliente AND ofertas.id_oferta_vuelo = _id_oferta_vuelo);
     SET _fechaSalida = (SELECT ofertas.fechaSalida FROM ofertas WHERE ofertas.id_cliente = _id_cliente AND ofertas.id_oferta_vuelo = _id_oferta_vuelo);
     SET _fechaRegreso = (SELECT ofertas.fechaRegreso FROM ofertas WHERE ofertas.id_cliente = _id_cliente AND ofertas.id_oferta_vuelo = _id_oferta_vuelo);
     SET _origen = (SELECT ofertas.origen FROM ofertas WHERE ofertas.id_cliente = _id_cliente AND ofertas.id_oferta_vuelo = _id_oferta_vuelo);
     SET _destino = (SELECT ofertas.destino FROM ofertas WHERE ofertas.id_cliente = _id_cliente AND ofertas.id_oferta_vuelo = _id_oferta_vuelo);
     SET _codigoIATAOrigen = (SELECT ofertas.codigoIATAOrigen FROM ofertas WHERE ofertas.id_cliente = _id_cliente AND ofertas.id_oferta_vuelo = _id_oferta_vuelo);
     SET _codigoIATADestino = (SELECT ofertas.codigoIATADestino FROM ofertas WHERE ofertas.id_cliente = _id_cliente AND ofertas.id_oferta_vuelo = _id_oferta_vuelo);
     SET _aerolineaSalida = (SELECT ofertas.aerolineaSalida FROM ofertas WHERE ofertas.id_cliente = _id_cliente AND ofertas.id_oferta_vuelo = _id_oferta_vuelo);
     SET _aerolineaRegreso = (SELECT ofertas.aerolineaRegreso FROM ofertas WHERE ofertas.id_cliente = _id_cliente AND ofertas.id_oferta_vuelo = _id_oferta_vuelo);

     INSERT INTO reservas(id_cliente,
                          precio,
                          vueloDirectoSalida,
                          vueloDirectoRegreso,
                          fechaSalida,
                          fechaRegreso,
                          origen,
                          destino,
                          codigoIATAOrigen,
                          codigoIATADestino,
                          aerolineaSalida,
                          aerolineaRegreso)
     VALUES(_id_cliente,
       _precio,
       _vueloDirectoSalida,
       _vueloDirectoRegreso,
       _fechaSalida,
       _fechaRegreso,
       _origen,
       _destino,
       _codigoIATAOrigen,
       _codigoIATADestino,
       _aerolineaSalida,
       _aerolineaRegreso);

   ELSE
     SIGNAL SQLSTATE '45000'
     SET MESSAGE_TEXT ='No existe dicha oferta para ese cliente.';
   END IF;
  ELSE
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT ='No existe ningun cliente registrado con este DNI.';
  END IF;
END