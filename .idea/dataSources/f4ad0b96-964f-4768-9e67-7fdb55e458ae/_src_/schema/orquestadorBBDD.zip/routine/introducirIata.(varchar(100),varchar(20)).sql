CREATE PROCEDURE `introducirIata`(IN `ciudad` VARCHAR(100), IN `codigoIATA` VARCHAR(20))
  BEGIN
  IF (SELECT count(*) FROM iata WHERE iata.codigoIATA = codigoIATA OR iata.ciudad = ciudad) = 0 THEN
    BEGIN
    INSERT INTO iata(ciudad, codigoIATA) values (ciudad,codigoIATA);
    END;
  END IF;
END