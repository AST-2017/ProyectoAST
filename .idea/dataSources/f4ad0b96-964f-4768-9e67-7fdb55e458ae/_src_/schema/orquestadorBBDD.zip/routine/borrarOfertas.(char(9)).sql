CREATE PROCEDURE `borrarOfertas`(IN `_dni` CHAR(9))
  BEGIN
  DECLARE _id_cliente INTEGER DEFAULT 0;

  IF(SELECT EXISTS(SELECT * FROM clientes WHERE clientes.dni = _dni)) THEN
    SET _id_cliente = (SELECT clientes.id FROM clientes WHERE clientes.dni = _dni);
    DELETE FROM ofertas WHERE ofertas.id_cliente = _id_cliente;
  ELSE
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT ='No existe ningun cliente registrado con este DNI.';
  END IF;
END