CREATE PROCEDURE `comprobarRegistro`(IN `_dni` CHAR(9), IN `_password` VARCHAR(100))
  BEGIN
  SELECT id FROM clientes WHERE clientes.dni = _dni AND clientes.password = _password;
END