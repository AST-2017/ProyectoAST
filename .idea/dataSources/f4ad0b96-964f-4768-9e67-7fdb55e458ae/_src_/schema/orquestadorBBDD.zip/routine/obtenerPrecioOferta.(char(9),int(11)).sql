CREATE PROCEDURE `obtenerPrecioOferta`(IN `_dni` CHAR(9), IN `_id_oferta_vuelo` INT(11))
  BEGIN
  IF(SELECT EXISTS(SELECT * FROM clientes WHERE clientes.dni = _dni)) THEN
    IF (SELECT EXISTS(SELECT *
                      FROM clientes,ofertas
                      WHERE
                        clientes.dni = _dni AND
                        clientes.id = ofertas.id_cliente AND
                        ofertas.id_oferta_vuelo = _id_oferta_vuelo)) THEN
      SELECT ofertas.precio
      FROM clientes,ofertas
      WHERE
        clientes.dni = _dni AND
        clientes.id = ofertas.id_cliente AND
        ofertas.id_oferta_vuelo = _id_oferta_vuelo;
    ELSE
      SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT ='No existe tal oferta para dicho cliente.';
    END IF;
  ELSE
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT ='No existe ningun cliente registrado con este DNI.';
  END IF;
END