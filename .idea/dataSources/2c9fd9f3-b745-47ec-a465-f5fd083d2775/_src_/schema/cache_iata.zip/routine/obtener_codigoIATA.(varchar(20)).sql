CREATE PROCEDURE `obtener_codigoIATA`(IN `ciudad` VARCHAR(20))
  BEGIN
  SELECT codigoIATA
  FROM iata
  WHERE iata.ciudad = ciudad;
END