The idea with this project to provide some additional plugins for the jUDDI Client to discover services using alternative mechanisms. 

Planned: Adapter using jgroups and mDNS to find a UDDI server and thus minimize the configuration data needed for using a jUDDI client to almost nothing.

Status: Incomplete 